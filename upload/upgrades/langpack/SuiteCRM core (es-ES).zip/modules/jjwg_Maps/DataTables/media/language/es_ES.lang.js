{
    "sEmptyTable":     "No hay datos disponibles en la tabla",
    "sInfo":           "Mostrando de _START_ a _END_ de _TOTAL_ entradas",
    "sInfoEmpty":      "Mostrando de 0 a 0 de 0 entradas",
    "sInfoFiltered":   "(filtrado de _MAX_ total entradas)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "Mostrar _MENU_ entradas",
    "sLoadingRecords": "Cargando...",
    "sProcessing":     "Procesando...",
    "sSearch":         "Buscar:",
    "sZeroRecords":    "No se han encontrado datos coincidentes",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": activar para ordenar la columna ascendentemente",
        "sSortDescending": ": activar para ordenar la columna descendentemente"
    }
}